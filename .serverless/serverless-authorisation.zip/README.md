# SportUnite App

#### Installation

*Install dependencies*
```Shell
npm i
npm i --only=dev
```

*Use environmentvariables [using DotEnv](https://github.com/motdotla/dotenv)*

Create an `.env` file in the root directory.

and use it like this *for example*:
`ALLOW_ORIGIN="http://localhost"`

#### Start

```Shell
npm start
```

#### Geocoding Google API Key
*Test Project*
```Test Project
AIzaSyBmjTbTi0rGZeXgTZ3njyCHgLwtMoOU1_s
```
