/**
 * Created by twanv on 21-12-2017.
 */
const googleMapsClient = require('@google/maps').createClient({
    key: 'AIzaSyBmjTbTi0rGZeXgTZ3njyCHgLwtMoOU1_s'
});

module.exports = googleMapsClient;